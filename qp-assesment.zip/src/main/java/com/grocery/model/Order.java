package com.grocery.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ElementCollection
    private List<Long> groceryItemIds;

    public Order() {}

    public Order(List<Long> groceryItemIds) {
        this.groceryItemIds = groceryItemIds;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Long> getGroceryItemIds() {
        return groceryItemIds;
    }

    public void setGroceryItemIds(List<Long> groceryItemIds) {
        this.groceryItemIds = groceryItemIds;
    }
}
