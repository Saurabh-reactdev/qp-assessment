package com.grocery.service;

import com.grocery.model.GroceryItem;
import com.grocery.model.Order;
import com.grocery.repository.GroceryItemRepository;
import com.grocery.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private GroceryItemRepository groceryItemRepository;

    public Order placeOrder(List<Long> groceryItemIds) {
        for (Long itemId : groceryItemIds) {
            Optional<GroceryItem> item = groceryItemRepository.findById(itemId);
            if (item.isEmpty()) {
                throw new RuntimeException("Item with ID " + itemId + " not found!");
            }
        }

        Order order = new Order(groceryItemIds);
        return orderRepository.save(order);
    }

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
}
