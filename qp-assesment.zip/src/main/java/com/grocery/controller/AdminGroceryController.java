package com.grocery.controller;

import com.grocery.model.GroceryItem;
import com.grocery.service.GroceryItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/admin/grocery")
public class AdminGroceryController {

    @Autowired
    private GroceryItemService groceryItemService;

    @PostMapping("/add")
    public GroceryItem addGroceryItem(@RequestBody GroceryItem item) {
        return groceryItemService.addGroceryItem(item);
    }

    @GetMapping("/all")
    public List<GroceryItem> getAllGroceryItems() {
        return groceryItemService.getAllGroceryItems();
    }

    @GetMapping("/{id}")
    public Optional<GroceryItem> getGroceryItemById(@PathVariable Long id) {
        return groceryItemService.getGroceryItemById(id);
    }

    @PutMapping("/update/{id}")
    public GroceryItem updateGroceryItem(@PathVariable Long id, @RequestBody GroceryItem updatedItem) {
        return groceryItemService.updateGroceryItem(id, updatedItem);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteGroceryItem(@PathVariable Long id) {
        groceryItemService.deleteGroceryItem(id);
        return "Grocery item deleted successfully";
    }
}
