package com.grocery.controller;

import com.grocery.model.GroceryItem;
import com.grocery.model.Order;
import com.grocery.service.GroceryItemService;
import com.grocery.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user/grocery")
public class UserGroceryController {

    @Autowired
    private GroceryItemService groceryItemService;

    @Autowired
    private OrderService orderService;

    @GetMapping("/available")
    public List<GroceryItem> getAvailableGroceries() {
        return groceryItemService.getAllGroceryItems();
    }

    @PostMapping("/order")
    public Order placeOrder(@RequestBody List<Long> groceryItemIds) {
        return orderService.placeOrder(groceryItemIds);
    }

    @GetMapping("/orders")
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }
}
